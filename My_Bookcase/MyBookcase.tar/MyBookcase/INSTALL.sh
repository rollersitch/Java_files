#!/bin/bash

sudo mkdir /opt/MyBookcase/
sudo cp MyBookcase.jar /opt/MyBookcase/
sudo cp translations.it.xml /opt/MyBookcase/
sudo cp MyBookcase /usr/bin/
sudo chmod +x /usr/bin/MyBookcase
