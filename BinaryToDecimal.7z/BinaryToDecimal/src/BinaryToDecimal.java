/*
 *      BinaryToDecimal.java
 *      
 *      Copyright 2010 Daniele Pipitone <dany-vai@hotmail.it>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Semplice calcolatrice per numeri binari e decimali; converte
 * gli uni negli altri e viceversa.
 * @author Daniele Pipitone
 * @version 1.0 24/05/2010
 */

public class BinaryToDecimal extends JFrame {
	/* Area di testo, il "display" della calcolatrice */
	private JTextArea area;
	/* Il pulsante di esecuzione */
	private JButton calcola;
	/* I due tasti di selezione modalità */
	private JRadioButton toDecimal;
	private JRadioButton toBinary;
	/* Pannello dei contenuti delle librerie swing */
	private Container sfondo;

	/** Costruisce la finestra principale,una finestra di
	 * 700x200 px formata da due pannelli, uno superiore che ospita
	 * il display e uno inferiore per il tasto calcola e i due tasti di
	 * selezione.
	 */ 
	public BinaryToDecimal() {
		setSize(700,200);
		setTitle("Convertitore Binario/Decimale");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		// setBackground(Color.green);										// TO-DO Rivedere la gestione grafica degli sfondi

		/* Acquisiamo il pannello dei contenuti */
		sfondo = getContentPane();

		/* Creiamo i due pannelli */
		JPanel pann1 = new JPanel();
		JPanel pann2 = new JPanel();

		/* Creazione dei tasti di selezione; li inseriamo in un ButtonGroup
		 * in modo che siano esclusivamente selezionabili.
		 */ 
		toDecimal = new JRadioButton("In decimale");
		toBinary = new JRadioButton("In binario");
		ButtonGroup gruppo = new ButtonGroup();
		gruppo.add(toDecimal);
		gruppo.add(toBinary);

		/* Il tasto di esecuzione */
		calcola = new JButton("Calcola");
		calcola.setSize(10,10);
		calcola.addActionListener(new Listener());

		/* Aggiungiamo al primo pannello l'area di testo */
		pann1.setLayout(new FlowLayout());
		
		area = new JTextArea("Inserisci qui il numero..",3,30);
		pann1.add(area);

		
		/* Aggiungiamo al secondo pannello il pulsante calcola e i due tasti
		 * di selzione.
		 */ 

		pann2.add(calcola);
		pann2.add(toDecimal);
		pann2.add(toBinary);

		/* Inseriamo i due pannelli nel contenitore principale */
		sfondo.add(pann2,"Center");
		sfondo.add(pann1,"North");
				
		setVisible(true);
	}
	/* Si potrebbe implementare la conversione da zero, ma dato che esistono appositi metodi
	 * mi sembra poco utile.
	 */ 
	//private String InDecimale() {return "a"; }
	//private String InBinario() {return "b"; }

	class Listener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// Conversione da decimale a binario
			if (toBinary.isSelected()) {
				String num1 = area.getText();
				int decimale1 = Integer.parseInt(num1);
				String binario1 = Integer.toBinaryString(decimale1);
				area.setText(binario1);
			}
			// Conversione da binario a decimale
			if (toDecimal.isSelected()) {
				String num2 = area.getText();
				Integer decimale2 = Integer.valueOf(num2,2);
				area.setText(decimale2.toString());
				
			}
					
		}
	}
}// class
