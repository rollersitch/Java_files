package com.cdsc.eje.gui.options;

import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

import com.cdsc.eje.gui.EJE;

/*
 * EJE - version 2.8 - "Everyone's Java Editor"
 * 
 * Copyright (C) 2003 Claudio De Sio Cesari
 * 
 * Require JDK 1.4
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * 
 * Info, Questions, Suggestions & Bugs Report to eje@claudiodesio.com
 *  
 */

public class EJEOptionsPanel extends EJEActivePanel {

	private final String[] languageValues = { "en", "it", "de" };

	private JComboBox languageCombo;

	private final String[] styleValues;

	private final UIManager.LookAndFeelInfo [] lookAndFeelInfo = UIManager
			.getInstalledLookAndFeels();

	private JComboBox styleCombo;

	private JPanel labelPanel;

	private JPanel stylePanel;

	private JPanel languagePanel;

	public EJEOptionsPanel() {
		languageCombo = new JComboBox(languageValues);
		styleValues = new String[lookAndFeelInfo.length];
		for (int i = 0; i < lookAndFeelInfo.length; i++) {
			styleValues[i] = lookAndFeelInfo[i].getName();
		}
		styleCombo = new JComboBox(styleValues);
		labelPanel = new JPanel();
		stylePanel = new JPanel();
		languagePanel = new JPanel();
		setup();
		addDetails();
	}

	private void addDetails() {
		reload();
	}

	public void reload() {
		UIManager.LookAndFeelInfo[] info = getLookAndFeelInfo();
		for (int i = 0; i < info.length; i++) {
			if (info[i].getClassName().equals(
					EJE.options.getProperty("eje.style"))) {
				styleCombo.setSelectedItem(info[i].getName());
				break;
			}
		}
		languageCombo.setSelectedItem(EJE.options.getProperty("eje.lang"));
	}

	private void setup() {
		setLayouts();
		labelPanel.add(new JLabel(EJE.resources.getString("options.label")));
		stylePanel.add(new JLabel(EJE.resources.getString("options.style")));
		languagePanel.add(new JLabel(EJE.resources
				.getString("options.language")));
		stylePanel.add(styleCombo);
		languagePanel.add(languageCombo);
		this.add(labelPanel);
		this.add(languagePanel);
		this.add(stylePanel);
	}

	private void setLayouts() {
		setLayout(new GridLayout(3, 1));
		languagePanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		stylePanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
	}

	public UIManager.LookAndFeelInfo[] getLookAndFeelInfo() {
		return lookAndFeelInfo;
	}

	public void store() {
		UIManager.LookAndFeelInfo[] info = getLookAndFeelInfo();
		for (int i = 0; i < info.length; i++) {
			if (info[i].getName().equals(styleCombo.getSelectedItem())) {
				EJE.options.setProperty("eje.style", info[i].getClassName());
				break;
			}
		}
		EJE.options.setProperty("eje.lang", languageCombo.getSelectedItem()
				.toString());
		super.store();
	}
}