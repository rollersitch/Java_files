package com.cdsc.eje.gui;

import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import com.cdsc.eje.entities.JavaFile;

/*
 * EJE - version 2.8 - "Everyone's Java Editor"
 * 
 * Copyright (C) 2003 Claudio De Sio Cesari
 * 
 * Require JDK 1.4
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * 
 * Info, Questions, Suggestions & Bugs Report to eje@claudiodesio.com
 *  
 */

public class EJETree extends JTree {
	public EJETree(DefaultMutableTreeNode root) {
		super(root);
		setup(root);
		registerComponents();
		addDetails();
	}

	private void setup(DefaultMutableTreeNode root) {
		loadProperties();
		createUserDirNodes(root, "user.work_dir");
		createUserDirNodes(root, "user.home");
		createTopNodes(root);
	}

	private void registerComponents() {
		this.addTreeSelectionListener(treeSelectionListener);
		this.addTreeExpansionListener(treeExpansionListener);
	}

	private void addDetails() {
		getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
		renderer.setLeafIcon(new ImageIcon("resources/images/javaicon.png"));
		renderer.setClosedIcon(new ImageIcon("resources/images/folder.png"));
		renderer.setOpenIcon(new ImageIcon("resources/images/openfolder.png"));
		this.setCellRenderer(renderer);
		this.setShowsRootHandles(true);
		this.expandRow(0);
	}

	private void loadProperties() {
		try {
			String workDir = EJE.options.getProperty("user.work_dir");
			System.setProperty("user.work_dir", workDir);
		} catch (Exception exc) {
			System.out.println(exc);
		}
	}

	public void createUserDirNodes(DefaultMutableTreeNode root, String dir) {
		try {
			File userDir = new File(System.getProperty(dir));
			if (!userDir.isDirectory())
				throw new Exception();
			EJEMutableTreeNode userDirNode = new EJEMutableTreeNode(userDir);
			root.add(userDirNode);
			userDirNode.createNodes();
		} catch (NullPointerException exc) {
			System.out.println("Work directory not specified");
		} catch (Exception exc) {
			System.out.println("Work directory not valid or not specified");
		}
	}

	private void createTopNodes(DefaultMutableTreeNode root) {
		File[] rootList = File.listRoots();
		FileSystemView view = FileSystemView.getFileSystemView();
		for (int i = 0; i < rootList.length; ++i) {
			if (!view.isFloppyDrive(rootList[i])) {
				if (view.isFileSystemRoot(rootList[i]) && rootList[i].exists()) {
					EJEMutableTreeNode node = new EJEMutableTreeNode(
							rootList[i]);
					root.add(node);
					//                node.createNodes();
				}
			}
		}
	}

	TreeSelectionListener treeSelectionListener = new TreeSelectionListener() {
		public synchronized void valueChanged(TreeSelectionEvent ev) {
			try {
				EJEMutableTreeNode node = (EJEMutableTreeNode) EJETree.this
						.getLastSelectedPathComponent();
				if (node == null)
					return;
				File file = node.getFile();
				if (file.isFile()) {
					EJE.getEJE().processOpenAction(
							new JavaFile(file.getParent(), file.getName()));
				}
				File fileNode = new File(node.toString());
				Object nodeInfo = node.getUserObject();
				node.createNodes();
			} catch (Exception exc) {
				System.out.println("Tree initialized");
			}
		}
	};

	TreeExpansionListener treeExpansionListener = new TreeExpansionListener() {
		public void treeCollapsed(TreeExpansionEvent event) {
		}

		public synchronized void treeExpanded(TreeExpansionEvent event) {
			try {
				EJEMutableTreeNode node = (EJEMutableTreeNode) event.getPath()
						.getLastPathComponent();
				node.createNodes();
				DefaultTreeModel model = (DefaultTreeModel) getModel();
				model.nodeStructureChanged(node);
			} catch (Exception exc) {
				System.out.println("Tree initialized");
			}

		}
	};

	/*
	 * class MyTreeModelListener implements TreeModelListener { public void
	 * treeNodesChanged(TreeModelEvent e) { DefaultMutableTreeNode node; node =
	 * (DefaultMutableTreeNode) (e.getTreePath().getLastPathComponent());
	 * 
	 * try { int index = e.getChildIndices()[0]; node = (DefaultMutableTreeNode)
	 * (node.getChildAt(index)); } catch (NullPointerException exc) {}
	 * 
	 * System.out.println("The user has finished editing the node.");
	 * System.out.println("New value: " + node.getUserObject()); } public void
	 * treeNodesInserted(TreeModelEvent e) { } public void
	 * treeNodesRemoved(TreeModelEvent e) { } public void
	 * treeStructureChanged(TreeModelEvent e) { } }
	 */
}