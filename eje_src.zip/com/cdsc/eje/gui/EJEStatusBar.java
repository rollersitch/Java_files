package com.cdsc.eje.gui;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.text.Element;

/*
 * EJE - version 2.8 - "Everyone's Java Editor"
 * 
 * Copyright (C) 2003 Claudio De Sio Cesari
 * 
 * Require JDK 1.4
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * 
 * Info, Questions, Suggestions & Bugs Report to eje@claudiodesio.com
 *  
 */

public class EJEStatusBar extends JPanel {
	protected JLabel messageLabel;

	protected JLabel actionLabel;

	protected JLabel lineLabel;

	protected JLabel processLabel;

	protected JPanel centerPanel;

	protected JPanel centerCenterPanel;

	protected EJEArea textArea;

	protected EJEClock ejeClock;

	protected String title;

	private static EJEStatusBar statusBar = null;

	private ImageIcon active;

	private ImageIcon inactive;

	private EJEStatusBar(String title) {
		this.title = "     " + title + "     ";
		inactive = new ImageIcon("resources/images/ylwled.png");
		active = new ImageIcon("resources/images/redled.png");
		centerPanel = new JPanel(new BorderLayout());
		centerCenterPanel = new JPanel();
		messageLabel = new JLabel(this.title);
		actionLabel = new JLabel("");
		lineLabel = new JLabel(EJE.resources
				.getString("options.java.version.using")
				+ System.getProperty("java.version"), JLabel.RIGHT);
		processLabel = new JLabel("", inactive, JLabel.LEFT);
		ejeClock = new EJEClock();
		setup();
	}

	public void setup() {
		setLayouts();
		add(messageLabel, BorderLayout.WEST);
		add(centerPanel, BorderLayout.CENTER);
		add(lineLabel, BorderLayout.EAST);
		centerPanel.add(ejeClock, BorderLayout.EAST);
		centerPanel.add(centerCenterPanel, BorderLayout.CENTER);
		centerCenterPanel.add(actionLabel, BorderLayout.WEST);
		centerCenterPanel.add(lineLabel, BorderLayout.EAST);
		centerPanel.add(centerCenterPanel, BorderLayout.CENTER);
		centerPanel.add(processLabel, BorderLayout.WEST);
		addDetails();
	}

	public void addDetails() {
		messageLabel.setFont(new Font("dialog", Font.BOLD, 11));
		lineLabel.setFont(new Font("dialog", Font.BOLD, 11));
		messageLabel.setBorder(BorderFactory.createEtchedBorder());
		lineLabel.setBorder(BorderFactory.createEtchedBorder());
		processLabel.setBorder(BorderFactory.createEtchedBorder());
		ejeClock.setBorder(BorderFactory.createEtchedBorder());
		centerPanel.setBorder(BorderFactory.createEtchedBorder());
	}

	public void setLayouts() {
		setLayout(new BorderLayout());
		centerCenterPanel.setLayout(new BorderLayout());
	}

	public void registerListeners() {

	}

	public void addAlarmTask(AlarmClockDialog.AlarmClockTimerTask alarmTask) {
		ejeClock.addAlarmTask(alarmTask);
	}

	public void removeAlarmTask(AlarmClockDialog.AlarmClockTimerTask alarmTask) {
		ejeClock.removeAlarmTask(alarmTask);
	}

	public static EJEStatusBar getStatusBar(String title) {
		if (statusBar == null) {
			statusBar = new EJEStatusBar(title);
		}
		return statusBar;
	}

	public static EJEStatusBar getStatusBar() {
		return statusBar;
	}

	public void setTextArea(EJEArea textArea) {
		this.textArea = textArea;
	}

	public int updateCaretPosition() {
		int caretPosition = textArea.getCaretPosition();
		Element element = textArea.getDocument().getDefaultRootElement();
		int rowNumber = element.getElementIndex(caretPosition);
		Element row = element.getElement(rowNumber);
		int firstColumnInRow = row.getStartOffset();
		int lastColumnInRow = row.getEndOffset();
		int rowCount = element.getElementCount();
		lineLabel.setText("     " + EJE.resources.getString("status.line")
				+ (rowNumber + 1) + "/" + rowCount + " "
				+ EJE.resources.getString("status.column")
				+ ((caretPosition - firstColumnInRow) + 1) + "/"
				+ (lastColumnInRow - firstColumnInRow) + " - "
				+ ((rowNumber + 1) * 100) / rowCount + "%     ");
		return rowCount;
	}

	public void changeColor(String processInAction) {
		Icon icon = inactive;
		if (!processInAction.equals("")) {
			icon = active;
		}
		actionLabel.setText(processInAction);
		processLabel.setIcon(icon);
	}
}