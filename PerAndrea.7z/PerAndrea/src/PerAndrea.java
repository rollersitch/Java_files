/*
 *      PerAndrea.java
 *      
 *      Copyright 2010 Daniele Pipitone <dany-vai@hotmail.it>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */
/* Importiamo le classi che servono per la realizzazione dell'applicazione */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/** Questa classe crea una semplice applicazione GUI che testa
 * la conoscenza dell'utente sulla principale caratteristica di
 * Andrea. <img src="./resources/andrea.gif" />
 * @author Daniele Pipitone
 * @version 1.0 23/05/2010
 * 
 */

public class PerAndrea extends JFrame {
	/** Il pulsante di "Submit" */
	private JButton pulsante;
	/** Il pannello dei contenuti,
	 * clicca {@link javax.swing.JFrame qui} per
	 * saperne di più.
	 */ 
	private Container sfondo;
	
	
	/** Campo di testo */
	/* Lo inizializziamo perchè di default verrebbe
	 * inizializzato a null, e il confronto nel gestore provocherebbe
	 * una NullPointerException.
	 */ 
	private JTextField testo = new JTextField();

	/** Area di testo */
	private JTextArea area;


	/** Costruttore unico, inizializza la finestra principale, usando
	 * i metodi ereditati da JFrame.
	 */ 
	public PerAndrea() {
		// Uso del setSize definito in JFrame
		setSize(700,700);
		// setTitle di JFrame (e così via)
		setTitle("Test di conoscenza su Andrea");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		// inizializzazione del pulsante
		JButton pulsante = new JButton("Controlla!!");
		// Creazione di un oggetto ascoltatore di eventi
		// Gestore gestore = new Gestore();


		// Registrazione del pulsante a un ascoltatore di eventi

		pulsante.addActionListener(new Gestore());

		// Acquisizione del pannello dei contenuti (il pannello principale "dentro" la finestra)

		sfondo = getContentPane();

		// Posizionamento del pulsante nel pannello dei contenuti

		sfondo.add(pulsante,"South");

		// Campo di testo
		// JTextField testo = new JTextField();
		testo.addActionListener(new Gestore());
		sfondo.add(testo,"North");

		// Creazione dell'etichetta
		area = new JTextArea("Questa è una applicazione di prova per vedere se conosci andrea, simile alla versione\n" +
										"esistente come script di shell, creata dato che lui sta inziando a studiare Java.\n" +
										"Quando sarai in grado di farne una di risposta,sarai già a buon livello. La domanda a \n" +
										"cui devi rispondere è : Andrea è una.....");
		sfondo.add(area,"Center");
		// Si spiega da solo.....
		setVisible(true);
	}

	/* Classe ascoltatrice di eventi, nel nostro caso
	 * l'evento è il clic sul pulsante.
	 */
	// Per capire questa devi prima studiare le interfacce
	class Gestore implements ActionListener {
		 // Override dell'unico metodo dell'interfaccia ActionListener
		public void actionPerformed(ActionEvent e) {
			// Questa è una asserzione, si lascia nel codice a scopo di documentazione
			assert testo != null;
			
			
				// Verifichiamo che il sorgente dell'evento sia il pulsante(un qualsiasi pulsante).
				// In questo caso non ce ne sarebbe bisogno, perchè c'è un solo pulsante.
			if (e.getSource() instanceof JButton || e.getSource() instanceof JTextField) {
				// Salviamo ciò che è scritto nel campo di testo, nella variabile risposta
				 String risposta = testo.getText();

				// Utilizziamo i metodi statici di JOptionPane per generare semplici messaggi.
				// Contemporaneamente useremo una dimostrazione semplice dell'uso dei thread
				
				if (risposta.equalsIgnoreCase("minchia")) {
					JOptionPane.showMessageDialog(null,"Bravo, Andrea è una minchia!!");
					try {
						Thread.sleep(1000);
					}
					catch (InterruptedException exce) { }
					JOptionPane.showMessageDialog(null,"Questa applicazione si distruggerà 10 secondi dopo che darai OK");
					try {
						Thread.sleep(10000);
					}
					catch (InterruptedException exc) { }
					System.exit(0);
				}
				else {
					JOptionPane.showMessageDialog(null,"No, Andrea non è una " + risposta + ", riprova!!");
				}
			}
		}
	}
}
			
